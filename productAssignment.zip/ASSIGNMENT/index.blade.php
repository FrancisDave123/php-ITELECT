<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <center>
    <h1>PRODUCT LIST</h1>
    <div>
        @if(session()->has('success'))
            {{session('success')}}
        @endif
    </div>
    <div>
        <table border='1'>
            <tr>
                <th>ID</th>
                <th>NAME</th>
                <th>DESCRIPTION</th>
                <th>PRICE</th>
                <th>DELETE</th>
            </tr>
            @foreach($products as $product)
            <tr>
                <td>{{$product->id}}</td>
                <td>{{$product->name}}</td>
                <td>{{$product->description}}</td>
                <td>{{$product->price}}</td>
                <td>
                    <form method ="post" action="{{route('product.delete', ['product' => $product])}}">            
                        @csrf
                        @method('delete')
                        <input type="submit" value ="Delete"/>
                    </form>
                </td>
            </tr>
            @endforeach 
        </table>
        <div>
            <button><a href="{{route('product.create')}}">ADD</a></button>
        </div>
    </div>
    </center>
</body>
</html>