<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <center>
    <h1>CREATE A PRODUCT</h1>
    <form method = "post" action ="{{route('product.store')}}">
        @csrf
        @method('post')
        <div>
            <label>NAME: </label>
            <input type="text" name= "name" placeholder="name" value="{{old('name')}}"/><br>
        </div>
        <div>
            <label>DESCRIPTION: </label>
            <input type="text" name= "description" placeholder="description" value="{{old('description')}}"/><br>
        </div>
        <div>
            <label>PRICE: </label>
            <input type="text" name= "price" placeholder="price" value="{{old('price')}}"/><br>
        </div>
        <div>
            <input type = "submit" value="Save a New Product"/><br>
        </div>
    </form>
    <div>
        @if($errors->any())
        <ul>
            @foreach($errors->all() as $error)
                    {{"- " . $error}}<br>
            @endforeach
        </ul>
        @endif
    </div>
    </center>
</body>
</html>